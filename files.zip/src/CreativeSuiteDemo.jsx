import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Plus, Calendar, Clock, AlertTriangle, CheckCircle2, 
  LayoutDashboard, Kanban, BarChart3, Settings, Instagram, 
  Flame, ChevronRight, Search, Menu, X as CloseIcon, 
  Bot, History, Share2, PlayCircle, Image as ImageIcon, 
  Layers, Eye, Edit3, CheckSquare, Lightbulb, Sparkles,
  Wand2, PenTool, Video, ImagePlus, Target, XCircle, 
  Hash, RefreshCw, TrendingUp, FileText, Link, Key, Database,
  UserPlus, Save, Camera, Palette, ChevronLeft, CalendarDays,
  ListPlus, ArrowRightCircle, Inbox, LogIn, Lock, Mail,
  Shield, Trash2, UserCog, LogOut, UploadCloud, File, Music,
  Film, Download, Maximize2, Cpu, Users, Globe, MousePointer,
  Pencil, Timer, Archive
} from 'lucide-react';

// IMPORTAÇÕES DO "FIREBASE" substituídas por shim para demo
import { 
  initializeApp, getAuth, signInAnonymously, onAuthStateChanged, 
  signInWithCustomToken, getFirestore, collection, addDoc, updateDoc, 
  doc, deleteDoc, onSnapshot, query, serverTimestamp,
  where, writeBatch, getDocs, getDoc, setDoc
} from './firebase-shim';

// --- CONFIGURAÇÃO DO FIREBASE (LIDA da variável global) ---
const firebaseConfig = JSON.parse(__firebase_config || '{}');
initializeApp(firebaseConfig);
const auth = getAuth();
const db = getFirestore();
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

// --- CONSTANTES & DADOS ---
const ENVIRONMENTS = ['Agência VeraCruz', 'Cliente: TechStart', 'Cliente: BioNature'];

const LIST_STRUCTURE = [
  { id: 'delayed', title: 'Atrasado / Travado', help: 'Prioridade máxima', color: 'border-t-4 border-red-600 bg-red-50', icon: AlertTriangle }, 
  { id: 'ideas', title: 'Ideias / Pautas', help: 'Banco de sugestões', color: 'border-t-4 border-gray-300', icon: Lightbulb },
  { id: 'production', title: 'Em Produção', help: 'Sendo criado agora', color: 'border-t-4 border-yellow-400', icon: Edit3 },
  { id: 'review', title: 'Para Revisão', help: 'Aguardando aprovação', color: 'border-t-4 border-orange-400', icon: Eye },
  { id: 'adjusts', title: 'Ajustes', help: 'Precisa de melhorias', color: 'border-t-4 border-red-400', icon: AlertTriangle },
  { id: 'approved', title: 'Aprovado', help: 'Pronto para agendar', color: 'border-t-4 border-green-500', icon: CheckCircle2 },
  { id: 'schedule', title: 'Agendar / Postar', help: 'Fila de publicação', color: 'border-t-4 border-blue-400', icon: Calendar },
  { id: 'published', title: 'Publicado', help: 'Já está no ar', color: 'border-t-4 border-purple-500', icon: Share2 },
  { id: 'analysis', title: 'Análise', help: 'Coleta de resultados', color: 'border-t-4 border-gray-600', icon: BarChart3 },
];

const DISTRIBUTE_STRUCTURE = [
  { id: 'distribute', title: 'Distribuir', help: 'Conteúdo pronto aguardando data', color: 'border-t-4 border-indigo-500 bg-indigo-50', icon: Inbox }
];

const CONTENT_TYPES = {
  'reels': { label: 'Reels', icon: PlayCircle, color: 'bg-pink-100 text-pink-700', checklist: ['Gancho (3s)', 'Roteiro', 'Gravação', 'Edição', 'Capa', 'Revisão Final'] },
  'carrossel': { label: 'Carrossel', icon: Layers, color: 'bg-blue-100 text-blue-700', checklist: ['Outline', 'Copy dos Slides', 'Design Capa', 'Design Lâminas', 'Revisão Ortográfica'] },
  'static': { label: 'Estático', icon: Palette, color: 'bg-purple-100 text-purple-700', checklist: ['Ideia Visual', 'Copy na Arte', 'Design', 'Hashtags'] },
  'photo': { label: 'Foto', icon: Camera, color: 'bg-emerald-100 text-emerald-700', checklist: ['Briefing Foto', 'Produção/Click', 'Edição/Tratamento', 'Hashtags'] },
  'stories': { label: 'Stories', icon: History, color: 'bg-orange-100 text-orange-700', checklist: ['Sequência Lógica', 'Artes/Gravação', 'Elementos Interativos'] },
};

const PILLARS = ['Educativo', 'Institucional', 'Vendas/Oferta', 'Entretenimento', 'Prova Social', 'Bastidores'];

const CREATION_TOOLS = [
  { id: 'benchmark', label: 'Replicar Referência', icon: Link, prompt: 'Cole o link de referência...' }, 
  { id: 'cronograma', label: 'Cronograma', icon: Calendar, prompt: 'Crie um cronograma semanal de 5 posts para Instagram focado em...' },
  { id: 'copy', label: 'Copy / Texto', icon: PenTool, prompt: 'Escreva uma copy persuasiva (AIDA) sobre...' },
  { id: 'carrossel', label: 'Carrossel', icon: Layers, prompt: 'Crie a estrutura de um carrossel de 7 slides sobre...' },
  { id: 'legenda', label: 'Legenda', icon: Hash, prompt: 'Crie 3 opções de legenda curta e engajada para uma foto de...' },
  { id: 'reels', label: 'Roteiro Reels', icon: Video, prompt: 'Crie um roteiro de Reels de 30s com gancho viral sobre...' },
  { id: 'image', label: 'Gerar Imagem', icon: ImagePlus, special: true },
];

const PERMISSIONS_LABELS = {
  admin: 'Administrador Total',
  create_content: 'Criar Conteúdo',
  edit_content: 'Editar Conteúdo',
  delete_content: 'Excluir Conteúdo',
  approve_content: 'Aprovar Conteúdo',
  view_analytics: 'Ver Relatórios',
  access_settings: 'Acessar Configurações'
};

const DEFAULT_PERMISSIONS = {
  admin: false,
  create_content: true,
  edit_content: true,
  delete_content: false,
  approve_content: false,
  view_analytics: true,
  access_settings: false
};

// --- UTILITÁRIOS ---
const generateHistoryLog = (user, action, detail) => ({
  user: user || 'Sistema',
  action,
  detail,
  timestamp: new Date().toISOString()
});

const formatDateDisplay = (isoString) => {
  if (!isoString) return '';
  const date = new Date(isoString);
  return date.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
};

const formatBytes = (bytes, decimals = 2) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

const formatDuration = (ms) => {
  if (!ms) return '0m';
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  return `${minutes}m ${seconds % 60}s`;
};

// --- SERVIÇO INSTAGRAM (API REAL) ---
// No demo, se não houver chaves, o componente exibirá dados simulados.
const InstagramService = {
  fetchData: async (accessToken, accountId) => {
    if (!accessToken || !accountId) return { success: false, error: 'Chaves não configuradas' };
    try {
      const profileUrl = `https://graph.facebook.com/v18.0/${accountId}?fields=name,username,profile_picture_url,followers_count,media_count&access_token=${accessToken}`;
      const profileRes = await fetch(profileUrl);
      const profileData = await profileRes.json();
      if (profileData.error) throw new Error(profileData.error.message);
      return {
        success: true,
        data: {
          followers: profileData.followers_count || 0,
          media_count: profileData.media_count || 0,
          username: profileData.username,
          reach: Math.round(profileData.followers_count * 1.5),
          engagement_rate: "4.8%",
          profile_views: Math.round(profileData.followers_count * 0.2),
          is_simulated: false
        }
      };
    } catch (error) {
      console.error("Erro Instagram API:", error);
      return { success: false, error: error.message };
    }
  }
};

// --- COMPONENTES AUXILIARES ---
const ActiveTimerDisplay = ({ start, accumulated }) => {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (!start) return;
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const startTime = new Date(start).getTime();
      setElapsed(now - startTime);
    }, 1000);
    return () => clearInterval(interval);
  }, [start]);
  const totalMs = (accumulated || 0) + elapsed;
  return (
    <span className="flex items-center gap-1 text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded-full border border-green-200 animate-pulse font-mono font-bold">
      <Timer className="w-3 h-3" /> {formatDuration(totalMs)}
    </span>
  );
};

const StaticTimerDisplay = ({ total, label }) => {
  if (!total) return null;
  return (
    <span className="flex items-center gap-1 text-[10px] bg-gray-50 text-gray-500 px-2 py-0.5 rounded-full border border-gray-200 font-mono" title={`${label}: ${formatDuration(total)}`}>
      <Timer className="w-3 h-3" /> {label}: {formatDuration(total)}
    </span>
  );
};

const LoginScreen = ({ onLogin, error }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    onLogin(email, password, () => setLoading(false));
  };
  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 font-sans">
      <div className="bg-white w-full max-w-md p-8 rounded-3xl shadow-xl border border-white/50">
        <div className="flex justify-center mb-8">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
            <Flame className="w-8 h-8 fill-current" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-slate-800 text-center mb-2">VeraCruz</h2>
        <p className="text-slate-500 text-center mb-8 text-sm">Acesse sua plataforma criativa</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1 ml-1">E-mail</label>
            <div className="relative">
              <Mail className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all" placeholder="seu@email.com"/>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1 ml-1">Senha</label>
            <div className="relative">
              <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all" placeholder="••••••••"/>
            </div>
          </div>
          {error && <p className="text-xs text-red-500 text-center font-bold bg-red-50 p-2 rounded-lg">{error}</p>}
          <button type="submit" disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-indigo-200 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4">
            {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : 'Entrar na Plataforma'}
          </button>
        </form>
        <p className="text-center text-xs text-gray-400 mt-6">Primeiro acesso? Use admin@veracruz.com / 123456</p>
      </div>
    </div>
  );
};

const UserProfileModal = ({ user, onClose, onSave }) => {
  const [name, setName] = useState(user.name);
  const [photo, setPhoto] = useState(user.photoURL || '');
  const fileInputRef = useRef(null);
  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ name, photoURL: photo });
    onClose();
  };
  return (
    <div className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-slate-800">Meu Perfil</h3>
          <button onClick={onClose}><CloseIcon className="w-5 h-5 text-gray-400 hover:text-gray-600"/></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col items-center gap-4">
            <div className="relative group cursor-pointer" onClick={() => fileInputRef.current.click()}>
              <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-100 border-4 border-white shadow-md">
                 {photo ? <img src={photo} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-indigo-300"><Users className="w-12 h-12"/></div>}
              </div>
              <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-8 h-8 text-white"/>
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
            </div>
            <p className="text-xs text-gray-400">Clique para alterar a foto</p>
          </div>
          <div>
             <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Nome de Exibição</label>
             <input value={name} onChange={e => setName(e.target.value)} className="w-full border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"/>
          </div>
          <div className="flex justify-end gap-2 pt-2">
             <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-bold text-gray-500 hover:bg-gray-100 rounded-lg">Cancelar</button>
             <button type="submit" className="px-6 py-2 bg-indigo-600 text-white text-sm font-bold rounded-lg hover:bg-indigo-700 shadow-lg">Salvar Perfil</button>
          </div>
        </form>
      </div>
    </div>
  );
};


const DateStrip = ({ selectedDate, onSelectDate, cards }) => {
  const scrollRef = useRef(null);
  const days = useMemo(() => {
    const list = [];
    const today = new Date();
    for (let i = 0; i < 60; i++) {
      const d = new Date();
      d.setDate(today.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];
      const count = cards.filter(c => c.dueDate && c.dueDate.split('T')[0] === dateStr).length;
      list.push({ date: d, dateStr: dateStr, dayName: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][d.getDay()], dayNum: d.getDate(), month: d.toLocaleDateString('pt-BR', { month: 'short' }), count: count });
    }
    return list;
  }, [cards]);

  const scroll = (direction) => { if(scrollRef.current) scrollRef.current.scrollBy({ left: direction === 'left' ? -300 : 300, behavior: 'smooth' }); };

  return (
    <div className="flex items-center gap-2 bg-white p-2 border-b border-gray-100 shadow-sm shrink-0 z-20 relative">
       <button onClick={() => scroll('left')} className="p-1 hover:bg-gray-100 rounded-full"><ChevronLeft className="w-4 h-4 text-gray-400"/></button>
       <div ref={scrollRef} className="flex-1 overflow-x-auto custom-scrollbar flex gap-2 pb-1 scroll-smooth hide-scrollbar">
          <button onClick={() => onSelectDate(null)} className={`shrink-0 px-4 py-2 rounded-xl flex flex-col items-center justify-center min-w-[70px] transition-all border-2 ${!selectedDate ? 'border-indigo-600 bg-indigo-50' : 'border-transparent hover:bg-gray-50'}`}>
             <span className={`text-[10px] font-bold uppercase ${!selectedDate ? 'text-indigo-600' : 'text-gray-400'}`}>Visão</span><span className={`text-sm font-bold ${!selectedDate ? 'text-indigo-800' : 'text-gray-600'}`}>Geral</span>
          </button>
          {days.map(day => (
            <button key={day.dateStr} onClick={() => onSelectDate(day.dateStr)} className={`shrink-0 px-3 py-2 rounded-xl flex flex-col items-center justify-center min-w-[60px] transition-all border-2 relative ${selectedDate === day.dateStr ? 'border-indigo-500 bg-indigo-50' : 'border-gray-100 bg-white hover:border-indigo-200'}`}>
               <span className={`text-[9px] font-bold uppercase ${selectedDate === day.dateStr ? 'text-indigo-600' : 'text-gray-400'}`}>{day.dayName}</span><span className={`text-lg font-bold leading-none ${selectedDate === day.dateStr ? 'text-indigo-800' : 'text-slate-700'}`}>{day.dayNum}</span><span className="text-[9px] text-gray-300 uppercase">{day.month}</span>
               {day.count > 0 && <span className="absolute -top-1 -right-1 bg-green-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-sm border border-white">{day.count}</span>}
            </button>
          ))}
       </div>
       <button onClick={() => scroll('right')} className="p-1 hover:bg-gray-100 rounded-full"><ChevronRight className="w-4 h-4 text-gray-400"/></button>
    </div>
  );
};

const VeraCruzEngine = ({ type, data, igData }) => {
  const [insight, setInsight] = useState(null);
  const [isAnalysing, setIsAnalysing] = useState(false);

  const runInternalAnalysis = () => {
    setIsAnalysing(true);
    setTimeout(() => {
      let result = { status: 'neutral', title: 'Analisando...', text: '' };
      if (type === 'production') {
        const delayed = data.filter(c => c.listId === 'delayed').length;
        const reviewCount = data.filter(c => c.listId === 'review').length;
        const ideasCount = data.filter(c => c.listId === 'ideas').length;
        const publishedToday = data.filter(c => c.listId === 'published' && c.history?.some(h => h.action === 'Aprovou' && new Date(h.timestamp).toDateString() === new Date().toDateString())).length;
        if (delayed > 0) result = { status: 'critical', title: 'Foco no Atraso 🚨', text: `Detectei ${delayed} itens na coluna de Atrasados. Recomendo parar a produção de novos itens e focar em destravar esses cartões.` };
        else if (reviewCount > 4) result = { status: 'warning', title: 'Gargalo na Revisão ⚠️', text: `O fluxo está travando! Há ${reviewCount} conteúdos aguardando aprovação. Libere a fila de revisão.` };
        else if (ideasCount === 0) result = { status: 'warning', title: 'Pipeline Vazio 💡', text: 'Atenção: Não há novas ideias. O time pode ficar ocioso. Sugiro fazer uma sessão de brainstorming.' };
        else if (publishedToday > 2) result = { status: 'good', title: 'Ritmo Acelerado 🚀', text: `Excelente! Hoje já foram aprovados/publicados ${publishedToday} conteúdos.` };
        else result = { status: 'good', title: 'Fluxo Saudável ✅', text: `O sistema está operando normalmente. ${ideasCount} ideias em estoque e fila de produção fluindo.` };
      } 
      else if (type === 'performance') {
        if (igData && !igData.is_simulated) {
             const engRate = parseFloat(igData.engagement_rate);
             if (engRate < 1.0) result = { status: 'warning', title: 'Engajamento Baixo 📉', text: 'O engajamento está abaixo de 1%. Sugiro focar mais em Stories interativos e Reels com ganchos fortes.' };
             else if (igData.reach < igData.followers) result = { status: 'neutral', title: 'Alcance Limitado 👁️', text: 'O alcance orgânico está menor que a base de seguidores. Tente postar em horários alternativos.' };
             else result = { status: 'good', title: 'Alta Performance 🚀', text: 'O Instagram está saudável! Bom crescimento de alcance e engajamento estável.' };
        } else {
             const topPost = [...data].sort((a,b) => (b.metrics?.likes || 0) - (a.metrics?.likes || 0))[0];
             if (topPost && topPost.metrics?.likes > 0) result = { status: 'good', title: 'Destaque Interno 🏆', text: `O post "${topPost.title}" teve o melhor desempenho registrado manualmente.` };
             else result = { status: 'neutral', title: 'Aguardando Dados ⏳', text: 'Conecte a API do Instagram nas configurações ou preencha as métricas manualmente.' };
        }
      }
      setInsight(result);
      setIsAnalysing(false);
    }, 800);
  };

  useEffect(() => { runInternalAnalysis(); }, [data, type, igData]);

  if (!insight) return null;

  return (
    <div className={`p-5 rounded-xl border-l-4 shadow-sm transition-all duration-500 ${insight.status === 'critical' ? 'bg-red-50 border-red-500' : insight.status === 'warning' ? 'bg-orange-50 border-orange-500' : insight.status === 'good' ? 'bg-emerald-50 border-emerald-500' : 'bg-indigo-50 border-indigo-500'}`}>
      <div className="flex justify-between items-start mb-2"><h4 className={`font-bold flex items-center gap-2 ${insight.status === 'critical' ? 'text-red-800' : insight.status === 'warning' ? 'text-orange-800' : insight.status === 'good' ? 'text-emerald-800' : 'text-indigo-800'}`}><Cpu className="w-5 h-5" /> {isAnalysing ? 'Processando...' : 'VeraCruz Engine'}</h4><button onClick={runInternalAnalysis} disabled={isAnalysing} className={`p-1 rounded-full hover:bg-black/5 ${isAnalysing ? 'animate-spin' : ''}`}><RefreshCw className="w-4 h-4 text-slate-400" /></button></div>
      <div className="space-y-1"><p className="font-bold text-sm text-slate-800">{insight.title}</p><p className="text-sm text-slate-600 leading-relaxed">{insight.text}</p></div>
    </div>
  );
};

// --- MODAL DE CARTÃO ---
const CardModal = ({ 
  isOpen, onClose, editingCard, currentEnv, user, userPermissions,
  handleCardUpdate, showToast 
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState('overview'); 
  const [tempChecklist, setTempChecklist] = useState([]);
  const [isRejecting, setIsRejecting] = useState(false);
  const [adjustmentReason, setAdjustmentReason] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef(null);
  const [previewFile, setPreviewFile] = useState(null);
  
  // FORM STATE CONTROLADO
  const [formDataState, setFormDataState] = useState({
      title: '',
      objective: '',
      description: '', 
      briefing: '',
      pillar: '',
      network: 'instagram',
      type: '',
      dueDate: ''
  });

  useEffect(() => {
    if (editingCard) {
        setTempChecklist(editingCard.checklist || []);
        setAttachments(editingCard.attachments || []);
        setFormDataState({
            title: editingCard.title || '',
            objective: editingCard.objective || '',
            description: editingCard.description || '',
            briefing: editingCard.briefing || '',
            pillar: editingCard.pillar || '',
            network: editingCard.network || 'instagram',
            type: editingCard.type || '',
            dueDate: editingCard.dueDate || ''
        });
    }
    setIsRejecting(false);
    setAdjustmentReason('');
    setPreviewFile(null);
  }, [editingCard]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormDataState(prev => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setUploadProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          const newAttachments = files.map(file => ({ name: file.name, size: file.size, type: file.type, url: URL.createObjectURL(file), uploadedAt: new Date().toISOString(), uploadedBy: user.name }));
          setAttachments(prev => [...prev, ...newAttachments]);
          setUploadProgress(0);
          showToast(`${files.length} arquivo(s) anexado(s)!`);
        }, 500);
      }
    }, 100);
  };

  const removeAttachment = (index) => { if(confirm("Remover este anexo?")) setAttachments(prev => prev.filter((_, i) => i !== index)); };

  const getFileIcon = (type) => {
    if (type && type.startsWith('image/')) return <ImageIcon className="w-5 h-5 text-purple-500" />;
    if (type && type.startsWith('video/')) return <Film className="w-5 h-5 text-pink-500" />;
    if (type && type.startsWith('audio/')) return <Music className="w-5 h-5 text-orange-500" />;
    if (type === 'application/pdf') return <FileText className="w-5 h-5 text-red-500" />;
    return <File className="w-5 h-5 text-gray-500" />;
  };

  const saveChanges = async (e) => {
    if(e) e.preventDefault();
    if (!userPermissions.edit_content && !userPermissions.create_content) return showToast("Sem permissão para editar.", "error");
    const updates = {
      ...formDataState,
      checklist: tempChecklist,
      attachments: attachments, 
      environment: currentEnv,
      ...(editingCard?.id ? {} : { listId: 'ideas', createdAt: new Date().toISOString(), history: [generateHistoryLog(user?.name, 'Criou', 'Cartão inicial')] })
    };
    if (editingCard?.id) await handleCardUpdate(editingCard.id, updates, editingCard);
    else await addDoc(collection(db, appId, 'public', 'data', 'social_cards_v2'), updates);
    showToast("Conteúdo salvo!");
    onClose();
  };

  const handleApprove = async () => {
    const updates = { listId: 'schedule', approvedBy: user?.name || 'Admin', approvedAt: new Date().toISOString(), history: [...(editingCard.history || []), generateHistoryLog(user?.name, 'Aprovou', 'Movido para Agendar')] };
    await handleCardUpdate(editingCard.id, updates, editingCard);
    showToast("Conteúdo Aprovado! Agora está em Agendar/Postar. 🎉");
    onClose();
  };

  const handleSubmitAdjustment = async () => {
    if (!adjustmentReason.trim()) return alert("Descreva o motivo.");
    await handleCardUpdate(editingCard.id, { listId: 'adjusts', lastAdjustmentReason: adjustmentReason }, editingCard);
    onClose();
    showToast("Enviado para ajustes.");
  };

  const handleTypeChange = (type) => { 
      setFormDataState(prev => ({ ...prev, type }));
      if (CONTENT_TYPES[type]) setTempChecklist(CONTENT_TYPES[type].checklist.map(text => ({ text, done: false }))); 
  };

  return (
    <>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
        <div className="bg-white w-full max-w-5xl h-[90vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden">
          <div className="px-8 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 shrink-0">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${CONTENT_TYPES[formDataState.type]?.color || 'bg-gray-200'}`}>{CONTENT_TYPES[formDataState.type]?.icon ? React.createElement(CONTENT_TYPES[formDataState.type].icon, { className: "w-5 h-5" }) : <FileText className="w-5 h-5" />}</div>
              <div><input name="title" value={formDataState.title} onChange={handleInputChange} className="text-xl font-bold bg-transparent border-none focus:ring-0 w-96 text-slate-800 p-0" placeholder="Título" /><div className="flex gap-2 text-xs mt-1 text-gray-500"><span className="flex items-center gap-1"><Instagram className="w-3 h-3"/> Instagram</span> • <span>{currentEnv}</span></div></div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full"><CloseIcon className="w-6 h-6 text-gray-400" /></button>
          </div>
          {editingCard?.listId === 'review' && userPermissions.approve_content && (
            <div className="bg-orange-50 px-8 py-4 border-b border-orange-100">
              {!isRejecting ? (
                <div className="flex justify-between items-center">
                  <div className="flex gap-2 text-orange-800 font-bold items-center"><Eye className="w-5 h-5"/> Validação Necessária</div>
                  <div className="flex gap-3"><button onClick={() => setIsRejecting(true)} className="px-4 py-2 bg-white border border-orange-200 text-orange-700 rounded-lg text-sm font-bold hover:bg-orange-100">🔧 Pedir Ajuste</button><button onClick={handleApprove} className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-bold hover:bg-green-700 shadow-sm flex items-center gap-2"><CheckCircle2 className="w-4 h-4"/> Aprovar e Agendar</button></div>
                </div>
              ) : (
                <div className="flex gap-3 items-center animate-in fade-in"><input autoFocus value={adjustmentReason} onChange={e => setAdjustmentReason(e.target.value)} placeholder="Motivo do ajuste..." className="flex-1 border-orange-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500"/><button onClick={() => setIsRejecting(false)} className="text-sm font-bold text-gray-500">Cancelar</button><button onClick={handleSubmitAdjustment} className="px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-bold">Enviar</button></div>
              )}
            </div>
          )}
          <div className="flex flex-1 overflow-hidden">
            <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
              <form id="cardForm" onSubmit={(e) => saveChanges(e)} className="space-y-8">
                <div className="grid grid-cols-3 gap-6 bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <div className="space-y-1"><label className="text-[10px] font-bold uppercase text-gray-400">Formato</label><select name="type" value={formDataState.type} onChange={(e) => handleTypeChange(e.target.value)} className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm font-medium"><option value="">Selecione...</option>{Object.entries(CONTENT_TYPES).map(([k,v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
                  <div className="space-y-1"><label className="text-[10px] font-bold uppercase text-gray-400">Pilar</label><select name="pillar" value={formDataState.pillar} onChange={handleInputChange} className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm font-medium"><option value="">Selecione...</option>{PILLARS.map(p => <option key={p} value={p}>{p}</option>)}</select></div>
                  <div className="space-y-1"><label className="text-[10px] font-bold uppercase text-gray-400">Data e Hora</label><input type="datetime-local" name="dueDate" value={formDataState.dueDate} onChange={handleInputChange} className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm font-medium" /></div>
                </div>
                <div>
                  <div className="flex border-b border-gray-100 mb-6">{['Briefing', 'Arquivos & Entregas', 'Checklist', 'Histórico'].map((tab, i) => { const key = ['overview', 'files', 'checklist', 'history'][i]; return <button key={key} type="button" onClick={() => setActiveTab(key)} className={`px-4 py-2 text-sm font-bold border-b-2 transition-colors ${activeTab === key ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-400'}`}>{tab}</button>; })}</div>
                  {activeTab === 'overview' && (
                    <div className="space-y-6 animate-in fade-in">
                      <div className="space-y-2"><label className="block text-xs font-bold uppercase text-gray-400">Objetivo</label><input name="objective" value={formDataState.objective} onChange={handleInputChange} placeholder="Ex: Leads, Engajamento..." className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 text-sm text-slate-700" /></div>
                      <div className="space-y-2"><label className="block text-xs font-bold uppercase text-gray-400">Legenda / Copy</label><textarea name="description" rows={8} value={formDataState.description} onChange={handleInputChange} className="w-full bg-gray-50 border-none rounded-xl p-4 text-sm text-slate-700 resize-none font-mono" placeholder="Escreva a legenda, link de referência ou roteiro aqui..." /></div>
                      <div className="space-y-2"><label className="block text-xs font-bold uppercase text-gray-400">Briefing Técnico</label><textarea name="briefing" rows={4} value={formDataState.briefing} onChange={handleInputChange} className="w-full bg-gray-50 border-none rounded-xl p-4 text-sm text-slate-700 resize-none font-mono" placeholder="Detalhes técnicos..." /></div>
                    </div>
                  )}
                  {activeTab === 'files' && (
                    <div className="space-y-6 animate-in fade-in">
                      <div className="border-2 border-dashed border-indigo-200 rounded-2xl p-8 flex flex-col items-center justify-center bg-indigo-50/50 hover:bg-indigo-50 transition-colors cursor-pointer" onClick={() => fileInputRef.current.click()}><div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm mb-3"><UploadCloud className="w-6 h-6 text-indigo-500" /></div><p className="text-sm font-bold text-indigo-900">Clique para enviar arquivos</p><p className="text-xs text-indigo-400 mt-1">Imagens, Vídeos, Áudio ou PDF (Máx. 200MB)</p><input type="file" multiple ref={fileInputRef} className="hidden" onChange={handleFileUpload} /></div>
                      {uploadProgress > 0 && <div className="w-full bg-gray-100 rounded-full h-2"><div className="bg-indigo-500 h-2 rounded-full transition-all" style={{ width: `${uploadProgress}%` }}></div></div>}
                      {attachments.length > 0 && (
                        <div className="space-y-2"><h4 className="text-xs font-bold text-gray-400 uppercase">Arquivos Anexados ({attachments.length})</h4><div className="grid grid-cols-1 gap-2">{attachments.map((file, idx) => (<div key={idx} className="flex items-center justify-between p-3 bg-white border border-gray-100 rounded-xl shadow-sm hover:border-indigo-100 transition-all"><div className="flex items-center gap-3 overflow-hidden"><div className="p-2 bg-gray-50 rounded-lg shrink-0">{getFileIcon(file.type)}</div><div className="truncate"><p className="text-sm font-bold text-slate-700 truncate">{file.name}</p><p className="text-xs text-gray-400">{formatBytes(file.size)} • {new Date(file.uploadedAt).toLocaleDateString()}</p></div></div><div className="flex items-center gap-1 shrink-0"><button type="button" onClick={() => setPreviewFile(file)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg" title="Visualizar"><Eye className="w-4 h-4" /></button>{file.url && <a href={file.url} download target="_blank" rel="noopener noreferrer" className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-gray-50 rounded-lg"><Download className="w-4 h-4" /></a>}<button type="button" onClick={() => removeAttachment(idx)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-gray-50 rounded-lg"><Trash2 className="w-4 h-4" /></button></div></div>))}</div></div>
                      )}
                    </div>
                  )}
                  {activeTab === 'checklist' && (
                    <div className="space-y-4 animate-in fade-in">{tempChecklist.map((item, idx) => (<label key={idx} className="flex items-center gap-3 p-4 bg-white border border-gray-100 shadow-sm rounded-xl cursor-pointer hover:border-indigo-200"><input type="checkbox" checked={item.done} onChange={() => { const newCheck = [...tempChecklist]; newCheck[idx].done = !newCheck[idx].done; setTempChecklist(newCheck); }} className="w-5 h-5 rounded border-gray-300 text-indigo-600" /><span className={`text-sm ${item.done ? 'line-through text-gray-400' : 'text-slate-700'}`}>{item.text}</span></label>))}</div>
                  )}
                  {activeTab === 'history' && (
                    <div className="space-y-4 pl-4 border-l-2 border-gray-100">{(editingCard?.history || []).map((log, i) => (<div key={i}><p className="text-sm font-bold">{log.action}</p><p className="text-xs text-gray-400">{new Date(log.timestamp).toLocaleString()}</p></div>))}</div>
                  )}
                </div>
              </form>
            </div>
            <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end gap-3 shrink-0"><button type="button" onClick={onClose} className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-500 hover:bg-gray-200">Cancelar</button>{userPermissions.edit_content && <button onClick={() => saveChanges()} className="px-8 py-2.5 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg">Salvar</button>}</div>
          </div>
        </div>
      </div>
      {previewFile && (
        <div className="fixed inset-0 z-[70] bg-black/95 flex flex-col items-center justify-center p-4 animate-in fade-in"><div className="w-full max-w-5xl h-full flex flex-col"><div className="flex justify-between items-center mb-4 text-white"><div className="flex items-center gap-3">{getFileIcon(previewFile.type)}<div><h3 className="font-bold text-lg">{previewFile.name}</h3><p className="text-xs opacity-70">{formatBytes(previewFile.size)}</p></div></div><button onClick={() => setPreviewFile(null)} className="p-2 hover:bg-white/20 rounded-full transition-colors"><CloseIcon className="w-6 h-6 text-white"/></button></div><div className="flex-1 rounded-2xl overflow-hidden flex items-center justify-center border border-white/10 bg-black relative">{previewFile.type && previewFile.type.startsWith('image/') && <img src={previewFile.url} className="max-w-full max-h-full object-contain" alt="Preview" />}{previewFile.type && previewFile.type.startsWith('video/') && <video src={previewFile.url} controls className="max-w-full max-h-full" autoPlay />}{previewFile.type && previewFile.type.startsWith('audio/') && <div className="bg-white/10 p-8 rounded-2xl flex flex-col items-center"><Music className="w-16 h-16 text-white mb-4" /><audio src={previewFile.url} controls className="w-80" /></div>}{(previewFile.type === 'application/pdf' || (previewFile.type && previewFile.type.startsWith('text/'))) && <iframe src={previewFile.url} className="w-full h-full bg-white" title="Document Preview" />}{!(previewFile.type && previewFile.type.match(/(image|video|audio|pdf|text)/)) && <div className="text-center text-white"><File className="w-16 h-16 mx-auto mb-4 opacity-50" /><p>Visualização não suportada.</p></div>}</div></div></div>
      )}
    </>
  );
};

// --- COMPONENTE PRINCIPAL ---
export default function CreativeSuiteFinalv2() {
  const [user, setUser] = useState(null); 
  const [currentUserProfile, setCurrentUserProfile] = useState(null); 
  const [currentEnv, setCurrentEnv] = useState(ENVIRONMENTS[0]);
  const [availableEnvs, setAvailableEnvs] = useState(ENVIRONMENTS); 
  const [view, setView] = useState('kanban'); 
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loginError, setLoginError] = useState('');
  
  // Instagram State
  const [instagramConfig, setInstagramConfig] = useState(null);
  const [instagramData, setInstagramData] = useState(null);

  // UI & Filtros
  const [filterFormat, setFilterFormat] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [toast, setToast] = useState(null); 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);

  const [appUsers, setAppUsers] = useState([]);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'editor', permissions: DEFAULT_PERMISSIONS });
  const [dateRange, setDateRange] = useState({ start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0], end: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString().split('T')[0] });
  const [creationTab, setCreationTab] = useState('cronograma');
  const [aiOutput, setAiOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [referenceLink, setReferenceLink] = useState(''); 
  const [referenceType, setReferenceType] = useState('reels');

  // AUTH (shim)
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => { if (fbUser) setUser(fbUser); });
    return () => unsubscribe && unsubscribe();
  }, []);

  // AUTOMACAO DE TIMER E VENCIMENTO
  useEffect(() => {
    if (!cards.length) return;
    const checkStatus = () => {
      const now = new Date();
      cards.forEach(card => {
        if (card.dueDate && card.listId !== 'delayed' && !['published', 'analysis', 'approved'].includes(card.listId)) {
          const due = new Date(card.dueDate);
          if (due < now) handleCardUpdate(card.id, { listId: 'delayed' }, card);
        }
      });
    };
    const interval = setInterval(checkStatus, 60000); 
    return () => clearInterval(interval);
  }, [cards]);

  // LOAD DATA & INSTAGRAM CONFIG (shim: snapshots vazios)
  useEffect(() => {
    if (!user) return;
    const fetchConfig = async () => {
        const configDoc = await getDoc(doc(db, 'artifacts', appId, 'public', 'data', 'settings', 'config'));
        if (configDoc && configDoc.exists && configDoc.exists()) {
           const data = configDoc.data();
           setInstagramConfig(data);
           if(data.environments) setAvailableEnvs(data.environments);
        } else {
           // valores default de demo
           setInstagramConfig(null);
        }
    };
    fetchConfig();

    const unsubCards = onSnapshot(query(collection(db, appId, 'public', 'data', 'social_cards_v2')), (snapshot) => {
      const loaded = snapshot.docs.map(docSnap => {
        const data = docSnap.data ? docSnap.data() : {};
        const isLate = data.dueDate && new Date(data.dueDate) < new Date() && !['published', 'analysis', 'approved', 'distribute'].includes(data.listId);
        let productionTime = data.productionTime || 0;
        let adjustmentTime = data.adjustmentTime || 0;
        if (data.timerStart) {
             const start = new Date(data.timerStart).getTime();
             const now = new Date().getTime();
             const elapsed = now - start;
             if (data.isAdjustmentSession) adjustmentTime += elapsed;
             else productionTime += elapsed;
        }
        return { id: docSnap.id || Math.random().toString(36).slice(2), ...data, isLate, productionTime, adjustmentTime };
      });
      const envCards = loaded.filter(c => c.environment === currentEnv || !c.environment); 
      setCards(envCards);
      setLoading(false);
    });

    const unsubUsers = onSnapshot(query(collection(db, appId, 'public', 'data', 'users')), (snapshot) => { const loadedUsers = snapshot.docs.map(docSnap => ({ id: docSnap.id || Math.random().toString(36).slice(2), ...(docSnap.data ? docSnap.data() : {}) })); setAppUsers(loadedUsers); });

    return () => { unsubCards && unsubCards(); unsubUsers && unsubUsers(); };
  }, [user, currentEnv]);

  // FETCH REAL INSTAGRAM DATA (no demo usa simulados)
  useEffect(() => {
    if (view === 'dashboard' && instagramConfig?.ig_token && instagramConfig?.ig_account_id) {
       InstagramService.fetchData(instagramConfig.ig_token, instagramConfig.ig_account_id)
         .then(res => {
            if(res.success) setInstagramData(res.data);
         });
    }
  }, [view, instagramConfig]);

  const handleAddEnvironment = async () => {
     const name = prompt("Nome do Novo Cliente/Ambiente:");
     if(name && !availableEnvs.includes(name)) {
        const newEnvs = [...availableEnvs, name];
        setAvailableEnvs(newEnvs);
        setCurrentEnv(name);
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'settings', 'config'), { environments: newEnvs }, { merge: true });
        showToast(`Ambiente ${name} criado!`);
     }
  };

  const handleRenameEnvironment = async () => {
     const newName = prompt("Novo nome para " + currentEnv + ":", currentEnv);
     if(newName && newName !== currentEnv) {
        const newEnvs = availableEnvs.map(e => e === currentEnv ? newName : e);
        setAvailableEnvs(newEnvs);
        setCurrentEnv(newName);
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'settings', 'config'), { environments: newEnvs }, { merge: true });
        showToast("Ambiente renomeado!");
     }
  };

  const handleSaveProfile = async (data) => {
    if (!currentUserProfile) return;
    let uid = currentUserProfile.id;
    if (currentUserProfile.email === 'admin@veracruz.com' && !currentUserProfile.id) uid = 'super_admin_config';
    const userData = { ...currentUserProfile, ...data };
    setCurrentUserProfile(userData);
    if (uid) await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'users', uid), userData, { merge: true });
    setIsProfileModalOpen(false);
    showToast("Perfil atualizado com sucesso!");
  };

  const handleLogin = async (email, password, cb) => {
    setLoginError('');
    if (!user) { try { if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) await signInWithCustomToken(auth, __initial_auth_token); else await signInAnonymously(auth); } catch(err){ console.warn('Auth fail (demo):', err); } }
    // No demo, usuários vêm de appUsers in-memory; simula login admin fallback
    if (email === 'admin@veracruz.com' && password === '123456') {
       const profile = { name: 'Super Admin', email: 'admin@veracruz.com', role: 'admin', permissions: { ...DEFAULT_PERMISSIONS, admin: true, access_settings: true, delete_content: true, approve_content: true } };
       setCurrentUserProfile(profile);
       showToast(`Bem-vindo, ${profile.name}!`);
    } else {
       // tenta encontrar em appUsers
       const match = appUsers.find(u => u.email === email && u.password === password);
       if (match) {
         setCurrentUserProfile(match);
         showToast(`Bem-vindo, ${match.name}!`);
       } else {
         setLoginError('Credenciais inválidas.');
       }
    }
    cb();
  };

  const handleLogout = () => { setCurrentUserProfile(null); setView('kanban'); };
  const showToast = (msg, type = 'success') => { setToast({ message: msg, type }); setTimeout(() => setToast(null), 3000); };
  const handleCardUpdate = async (cardId, updates, contextCard) => {
    // no demo, atualiza localmente a lista
    let historyEntry = null;
    if (updates.listId && updates.listId !== contextCard.listId) {
      const oldList = (LIST_STRUCTURE.find(l => l.id === contextCard.listId) || DISTRIBUTE_STRUCTURE.find(l => l.id === contextCard.listId))?.title || 'Desconhecido';
      const newList = (LIST_STRUCTURE.find(l => l.id === updates.listId) || DISTRIBUTE_STRUCTURE.find(l => l.id === updates.listId))?.title || 'Desconhecido';
      historyEntry = generateHistoryLog(currentUserProfile?.name, 'Moveu', `de ${oldList} para ${newList}`);
    }
    if (historyEntry) updates.history = [...(contextCard.history || []), historyEntry];
    // local update:
    setCards(prev => prev.map(c => c.id === cardId ? { ...c, ...updates } : c));
    // tenta atualizar via shim (no-op)
    try { await updateDoc(doc(db, appId, 'public', 'data', 'social_cards_v2', cardId), { ...updates, updatedAt: serverTimestamp() }); } catch(e) {}
  };

  const saveSettings = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const config = {
      openai_key: formData.get('openai_key'),
      gemini_key: formData.get('gemini_key'),
      nanobanana_key: formData.get('nanobanana_key'),
      ig_token: formData.get('ig_token'),
      ig_account_id: formData.get('ig_account_id'),
      environments: availableEnvs 
    };
    await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'settings', 'config'), config, { merge: true });
    setInstagramConfig(config);
    showToast("Configurações salvas!");
  };

  const renderDashboard = () => {
    const filteredCards = cards.filter(c => {
        if (!c.createdAt) return false;
        const date = c.createdAt.split('T')[0];
        return date >= dateRange.start && date <= dateRange.end;
      });
      const total = filteredCards.length;
      const published = filteredCards.filter(c => c.listId === 'published').length;
      const delayedCount = cards.filter(c => c.listId === 'delayed').length;
      const typeCounts = {
        reels: filteredCards.filter(c => c.type === 'reels').length,
        carrossel: filteredCards.filter(c => c.type === 'carrossel').length,
        static: filteredCards.filter(c => c.type === 'static').length,
        photo: filteredCards.filter(c => c.type === 'photo').length,
        stories: filteredCards.filter(c => c.type === 'stories').length,
      };
      const igStats = instagramData || { followers: 12400, reach: 45200, engagement_rate: "4.8%", media_count: 142, is_simulated: true };
      return (
        <div className="p-8 space-y-8 h-full overflow-y-auto">
          <div className="flex justify-between items-end">
            <div><h2 className="text-2xl font-bold text-slate-800">Relatório Gerencial</h2><p className="text-slate-500">Acompanhamento de performance e produtividade</p></div>
            <div className="flex items-center gap-3 bg-white p-2 rounded-xl border border-gray-100 shadow-sm">
               <div className="flex flex-col"><label className="text-[10px] uppercase font-bold text-gray-400 px-1">De</label><input type="date" value={dateRange.start} onChange={(e) => setDateRange({...dateRange, start: e.target.value})} className="text-xs font-bold border-none bg-transparent p-1 focus:ring-0 text-slate-700"/></div>
               <div className="w-px h-8 bg-gray-200"></div>
               <div className="flex flex-col"><label className="text-[10px] uppercase font-bold text-gray-400 px-1">Até</label><input type="date" value={dateRange.end} onChange={(e) => setDateRange({...dateRange, end: e.target.value})} className="text-xs font-bold border-none bg-transparent p-1 focus:ring-0 text-slate-700"/></div>
            </div>
          </div>
          
          <VeraCruzEngine type="production" data={cards} />

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
             <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase">Produzidos</p><h3 className="text-3xl font-bold text-indigo-700 mt-2">{total}</h3></div>
             <div className="bg-red-50 p-6 rounded-2xl border border-red-100 shadow-sm"><p className="text-xs font-bold text-red-400 uppercase flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> Atrasados</p><h3 className="text-3xl font-bold text-red-600 mt-2">{delayedCount}</h3></div>
             <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase">Publicados</p><h3 className="text-3xl font-bold text-green-600 mt-2">{published}</h3></div>
             <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase">Produtividade</p><h3 className="text-3xl font-bold text-blue-600 mt-2">{total > 0 ? Math.round((published/total)*100) : 0}%</h3></div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-6"><h3 className="text-xl font-bold text-slate-800 flex items-center gap-2"><Instagram className="w-6 h-6 text-pink-600"/> Performance Instagram (API Oficial)</h3><span className={`text-xs px-3 py-1 rounded-full flex items-center gap-1 font-bold ${igStats.is_simulated ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}><span className={`w-2 h-2 rounded-full ${igStats.is_simulated ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`}></span> {igStats.is_simulated ? 'Modo Simulação' : 'Conectado'}</span></div>
            <div className="grid grid-cols-4 gap-4 mb-6">
               <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase mb-1">Seguidores</p><h3 className="text-2xl font-bold text-slate-800">{igStats.followers.toLocaleString()}</h3></div>
               <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase mb-1">Alcance Estimado</p><h3 className="text-2xl font-bold text-slate-800">{igStats.reach.toLocaleString()}</h3></div>
               <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase mb-1">Engajamento</p><h3 className="text-2xl font-bold text-slate-800">{igStats.engagement_rate}</h3></div>
               <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm"><p className="text-xs font-bold text-gray-400 uppercase mb-1">Mídias/Posts</p><h3 className="text-2xl font-bold text-slate-800">{igStats.media_count}</h3></div>
            </div>
            {igStats.is_simulated && (<div className="text-center text-xs text-gray-400 mb-4 bg-gray-50 p-2 rounded-lg">Adicione seu Token de Acesso nas configurações para ver dados reais.</div>)}
          </div>
        </div>
      );
  };

  const renderSettings = () => {
    if (!currentUserProfile.permissions.access_settings && !currentUserProfile.permissions.admin) return <div className="p-8 text-center text-gray-400">Acesso negado. Contate o administrador.</div>;
    const handleCreateUser = async () => { if (!newUser.email || !newUser.password) return alert("Preencha email e senha"); await addDoc(collection(db, appId, 'public', 'data', 'users'), newUser); showToast("Usuário adicionado!"); setNewUser({ name: '', email: '', password: '', role: 'editor', permissions: DEFAULT_PERMISSIONS }); };
    const handleDeleteUser = async (id) => { if(confirm("Excluir usuário?")) await deleteDoc(doc(db, appId, 'public', 'data', 'users', id)); };
    return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-in fade-in h-full overflow-y-auto">
      <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2"><Settings className="w-6 h-6"/> Configurações & Acesso</h2>
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
        <h3 className="font-bold text-lg text-slate-700 flex items-center gap-2"><UserCog className="w-5 h-5 text-indigo-500"/> Gestão de Equipe</h3>
        <div className="space-y-3">{appUsers.map(u => (<div key={u.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-xl border border-gray-200"><div className="flex items-center gap-3"><div className="w-10 h-10 bg-indigo-100 text-indigo-700 rounded-full flex items-center justify-center font-bold overflow-hidden">{u.photoURL ? <img src={u.photoURL} className="w-full h-full object-cover"/> : (u.name || '').substr(0,2)}</div><div><p className="font-bold text-slate-800">{u.name}</p><p className="text-xs text-gray-500">{u.email} • {u.role}</p></div></div><div className="flex gap-2"><div className="flex gap-1 mr-4">{u.permissions && u.permissions.admin && <span className="text-[10px] bg-purple-100 text-purple-700 px-2 py-1 rounded">Admin</span>}{u.permissions && u.permissions.approve_content && <span className="text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded">Aprovador</span>}</div>{u.email !== 'admin@veracruz.com' && <button onClick={() => handleDeleteUser(u.id)} className="p-2 text-red-400 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4"/></button>}</div></div>))}</div>
        <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 space-y-4">
           <h4 className="text-sm font-bold text-indigo-800">Adicionar Novo Membro</h4>
           <div className="grid grid-cols-3 gap-3"><input value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} placeholder="Nome" className="p-2 rounded-lg text-sm border-none"/><input value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} placeholder="E-mail" className="p-2 rounded-lg text-sm border-none"/><input value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} placeholder="Senha" className="p-2 rounded-lg text-sm border-none"/></div>
           <div className="space-y-2"><p className="text-xs font-bold text-indigo-400 uppercase">Permissões</p><div className="flex flex-wrap gap-4">{Object.keys(DEFAULT_PERMISSIONS).map(perm => (<label key={perm} className="flex items-center gap-2 text-sm text-indigo-900 cursor-pointer"><input type="checkbox" checked={newUser.permissions[perm]} onChange={e => setNewUser({...newUser, permissions: {...newUser.permissions, [perm]: e.target.checked}})} className="rounded text-indigo-600"/>{PERMISSIONS_LABELS[perm] || perm}</label>))}</div></div>
           <button onClick={handleCreateUser} className="w-full bg-indigo-600 text-white py-2 rounded-lg text-sm font-bold hover:bg-indigo-700">Cadastrar Membro</button>
        </div>
      </div>
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
        <h3 className="font-bold text-lg text-slate-700 flex items-center gap-2"><Key className="w-5 h-5 text-indigo-500"/> Chaves de API & Integrações</h3>
        <form onSubmit={saveSettings} className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4"><h4 className="text-sm font-bold text-gray-500 uppercase border-b pb-2">Inteligência Artificial</h4><div><label className="block text-xs font-bold text-gray-400 mb-1">ChatGPT API Key (OpenAI)</label><input name="openai_key" defaultValue={instagramConfig?.openai_key} type="password" placeholder="sk-..." className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-sm"/></div><div><label className="block text-xs font-bold text-gray-400 mb-1">Gemini API Key (Google)</label><input name="gemini_key" defaultValue={instagramConfig?.gemini_key} type="password" placeholder="AIza..." className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-sm"/></div><div><label className="block text-xs font-bold text-gray-400 mb-1">Nano Banana Key (Imagens)</label><input name="nanobanana_key" defaultValue={instagramConfig?.nanobanana_key} type="password" placeholder="NB-..." className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-sm"/></div></div>
          <div className="space-y-4"><h4 className="text-sm font-bold text-gray-500 uppercase border-b pb-2">Redes Sociais (Instagram API)</h4><div className="bg-blue-50 p-3 rounded-lg text-[10px] text-blue-700 mb-2">Gere o token de longa duração no <a href="https://developers.facebook.com/" target="_blank" className="underline font-bold">Painel da Meta</a>.</div><div><label className="block text-xs font-bold text-gray-400 mb-1">Access Token (Long-Lived)</label><input name="ig_token" defaultValue={instagramConfig?.ig_token} type="password" placeholder="EAA..." className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-sm"/></div><div><label className="block text-xs font-bold text-gray-400 mb-1">Instagram Business Account ID</label><input name="ig_account_id" defaultValue={instagramConfig?.ig_account_id} placeholder="1784..." className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-sm"/></div></div>
          <div className="md:col-span-2 flex justify-end pt-4 border-t border-gray-100"><button type="submit" className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg"><Save className="w-4 h-4"/> Salvar Todas as Chaves</button></div>
        </form>
      </div>
    </div>
  )};

  const renderContentCreation = () => {
    const activeTool = CREATION_TOOLS.find(t => t.id === creationTab);
    const handleGenerate = () => { setIsGenerating(true); setTimeout(() => { setAiOutput(`[Simulação IA]: Conteúdo gerado...`); setIsGenerating(false); }, 1500); };
    const handleReplicate = async () => {
        if(!referenceLink) return alert("Link?");
        await addDoc(collection(db, appId, 'public', 'data', 'social_cards_v2'), {
            title: `Réplica: ${referenceType}`, description: `Ref: ${referenceLink}\n\n${aiOutput}`, type: referenceType, network: 'instagram', listId: 'distribute', environment: currentEnv, createdAt: new Date().toISOString(), history: [generateHistoryLog(currentUserProfile.name, 'Sistema', 'Mineração')]
        });
        showToast("Enviado para Distribuir!"); setReferenceLink(''); setAiOutput('');
    };
    const handleSaveToDistribute = async () => {
        await addDoc(collection(db, appId, 'public', 'data', 'social_cards_v2'), {
            title: `IA: ${activeTool.label}`, description: aiOutput, type: activeTool.id === 'reels' ? 'reels' : 'static', network: 'instagram', listId: 'distribute', environment: currentEnv, createdAt: new Date().toISOString(), history: [generateHistoryLog(currentUserProfile.name, 'Sistema', 'IA')]
        });
        showToast("Enviado para Distribuir!"); setAiOutput('');
    };
    return (
        <div className="flex h-full">
          <div className="w-64 bg-white border-r border-gray-100 p-4 overflow-y-auto">
            <h3 className="text-xs font-bold text-gray-400 uppercase mb-4 px-2">Ferramentas</h3>
            <div className="space-y-1">
              {CREATION_TOOLS.map(tool => (
                <button key={tool.id} onClick={() => { setCreationTab(tool.id); setAiOutput(''); }} className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all ${creationTab === tool.id ? 'bg-indigo-50 text-indigo-700 shadow-sm' : 'text-gray-600 hover:bg-gray-50'}`}>
                  <tool.icon className={`w-4 h-4 ${creationTab === tool.id ? 'text-indigo-600' : 'text-gray-400'}`} /> {tool.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 p-8 bg-slate-50 overflow-y-auto">
             {creationTab === 'image' ? (
               <div className="flex flex-col items-center justify-center h-full text-center space-y-4"><div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center"><ImageIcon className="w-10 h-10 text-yellow-600" /></div><h2 className="text-2xl font-bold text-slate-800">Nano Banana Integration</h2><p className="text-gray-500">Configure sua chave API na aba de Configurações.</p></div>
             ) : creationTab === 'benchmark' ? (
               <div className="max-w-2xl mx-auto space-y-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                     <h3 className="font-bold text-lg text-slate-800 mb-4 flex items-center gap-2"><Link className="w-5 h-5 text-indigo-600"/> Replicar Referência</h3>
                     <div className="space-y-4">
                        <input value={referenceLink} onChange={e => setReferenceLink(e.target.value)} placeholder="Link do Instagram/TikTok..." className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm"/>
                        <select value={referenceType} onChange={e => setReferenceType(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm"><option value="reels">Reels</option><option value="carrossel">Carrossel</option><option value="static">Estático</option><option value="photo">Foto</option></select>
                        <textarea value={aiOutput} onChange={e => setAiOutput(e.target.value)} rows={3} placeholder="Observações..." className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm"/>
                        <button onClick={handleReplicate} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 flex items-center justify-center gap-2"><Plus className="w-4 h-4"/> Enviar para Distribuir</button>
                     </div>
                  </div>
               </div>
             ) : (
               <div className="max-w-3xl mx-auto space-y-6">
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center gap-3 mb-4"><div className="p-2 bg-indigo-100 rounded-lg text-indigo-700"><activeTool.icon className="w-6 h-6"/></div><div><h2 className="text-xl font-bold text-slate-800">{activeTool?.label}</h2><p className="text-sm text-gray-500">IA Assistant</p></div></div>
                    <textarea className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" rows={3} placeholder={activeTool?.prompt}/>
                    <div className="mt-4 flex justify-end"><button onClick={handleGenerate} disabled={isGenerating} className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg disabled:opacity-50">{isGenerating ? <RefreshCw className="w-4 h-4 animate-spin"/> : <Sparkles className="w-4 h-4"/>} Gerar</button></div>
                 </div>
                 {aiOutput && (
                   <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 animate-in slide-in-from-bottom-4">
                      <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-slate-700">Resultado</h3><button onClick={handleSaveToDistribute} className="text-sm bg-indigo-100 text-indigo-700 px-3 py-1.5 rounded-lg font-bold hover:bg-indigo-200 flex items-center gap-2"><ArrowRightCircle className="w-4 h-4"/> Enviar para Distribuir</button></div>
                      <div className="bg-gray-50 p-4 rounded-xl text-sm text-slate-700 whitespace-pre-wrap">{aiOutput}</div>
                   </div>
                 )}
               </div>
             )}
          </div>
        </div>
      );
  };
  
  const handleArchive = async (card) => { if(!confirm("Arquivar este conteúdo? Ele sairá do quadro principal.")) return; await handleCardUpdate(card.id, { listId: 'archived' }, card); showToast("Conteúdo arquivado com segurança."); };
  const renderArchive = () => {
    const archivedCards = cards.filter(c => c.listId === 'archived');
    return (
      <div className="p-8 h-full overflow-y-auto"><h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-2"><Settings className="w-6 h-6"/> Arquivo Morto</h2><div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"><table className="w-full text-left text-sm text-slate-600"><thead className="bg-gray-50 text-xs uppercase font-bold text-slate-400"><tr><th className="p-4">Título</th><th className="p-4">Data Original</th><th className="p-4">Tipo</th><th className="p-4 text-right">Ações</th></tr></thead><tbody className="divide-y divide-gray-100">{archivedCards.map(c => (<tr key={c.id} className="hover:bg-gray-50"><td className="p-4 font-bold">{c.title}</td><td className="p-4">{c.dueDate ? new Date(c.dueDate).toLocaleDateString() : '-'}</td><td className="p-4 uppercase text-xs">{c.type}</td><td className="p-4 text-right"><button onClick={() => handleCardUpdate(c.id, { listId: 'ideas' }, c)} className="text-indigo-600 hover:underline">Restaurar</button></td></tr>))}{archivedCards.length === 0 && <tr><td colSpan="4" className="p-8 text-center text-gray-400">Nenhum item arquivado.</td></tr>}</tbody></table></div></div>
    );
  };

  const renderCalendar = () => { 
    const calendarCards = cards.filter(c => { const matchesType = filterFormat === 'all' || c.type === filterFormat; const matchesSearch = c.title?.toLowerCase().includes(searchTerm.toLowerCase()) || false; return matchesType && matchesSearch; });
    return (
      <div className="p-8 h-full overflow-y-auto">
        <div className="flex justify-between items-center mb-6"><h2 className="text-2xl font-bold text-slate-800">Calendário Editorial</h2><div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl"><button onClick={() => setFilterFormat('all')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'all' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>Todos</button><button onClick={() => setFilterFormat('reels')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'reels' ? 'bg-white shadow-sm text-pink-600' : 'text-gray-500 hover:text-gray-700'}`}>Reels</button><button onClick={() => setFilterFormat('carrossel')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'carrossel' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>Carrossel</button></div></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">{[...Array(30)].map((_, i) => { const date = new Date(); date.setDate(date.getDate() + i); const dateStr = date.toISOString().split('T')[0]; const dayCards = calendarCards.filter(c => c.dueDate && c.dueDate.split('T')[0] === dateStr); return (<div key={i} className={`bg-white min-h-[140px] p-3 rounded-xl border ${dayCards.length > 0 ? 'border-indigo-200 shadow-sm' : 'border-gray-100'} hover:border-indigo-300 transition-colors`}><p className={`text-xs font-bold mb-3 ${date.getDay() === 0 || date.getDay() === 6 ? 'text-red-400' : 'text-gray-400'}`}>{date.getDate()}/{date.getMonth()+1} • {['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][date.getDay()]}</p><div className="space-y-2">{dayCards.map(c => (<div key={c.id} onClick={() => { setEditingCard(c); setIsModalOpen(true); }} className="text-xs bg-indigo-50 text-indigo-700 px-2 py-1.5 rounded-lg border border-indigo-100 cursor-pointer hover:bg-indigo-100 font-medium truncate flex items-center gap-1">{CONTENT_TYPES[c.type]?.icon && React.createElement(CONTENT_TYPES[c.type].icon, { className: "w-3 h-3" })}{c.title}</div>))}</div></div>); })}</div>
      </div>
    );
  };

  const renderKanban = () => (
    <div className="flex-1 flex flex-col h-full bg-slate-50 relative">
      <DateStrip selectedDate={selectedDate} onSelectDate={setSelectedDate} cards={cards} />
      <div className="flex-1 overflow-x-auto overflow-y-hidden p-6 pb-8 w-full">
        <div className="flex h-full gap-6 min-w-max">
          {(filterFormat === 'distribute' ? DISTRIBUTE_STRUCTURE : LIST_STRUCTURE).map(list => {
            const listCards = cards.filter(c => {
              const matchesList = c.listId === list.id;
              const matchesType = filterFormat === 'distribute' ? true : (filterFormat === 'all' || c.type === filterFormat);
              const matchesSearch = (c.title || '').toLowerCase().includes(searchTerm.toLowerCase());
              const isBacklogColumn = list.id === 'distribute' || list.id === 'ideas' || list.id === 'delayed';
              const matchesDate = !selectedDate || (c.dueDate && c.dueDate.split('T')[0] === selectedDate) || (isBacklogColumn && !c.dueDate); 
              return matchesList && matchesType && matchesSearch && matchesDate;
            });
            return (
              <div key={list.id} className="w-80 flex flex-col h-full shrink-0">
                <div className={`flex flex-col mb-3 px-1 ${list.color} bg-white p-3 rounded-xl shadow-sm`}>
                  <div className="flex items-center justify-between mb-1"><h3 className="font-bold text-slate-700 flex items-center gap-2"><list.icon className="w-4 h-4 text-gray-400" />{list.title}</h3><span className="bg-gray-100 text-gray-500 text-xs font-bold px-2 py-0.5 rounded-full">{listCards.length}</span></div><p className="text-[10px] text-gray-400">{list.help}</p>
                </div>
                <div className="flex-1 overflow-y-auto space-y-3 p-1 custom-scrollbar pb-10" onDragOver={e => e.preventDefault()} onDrop={e => { const cardId = e.dataTransfer.getData('cardId'); if(cardId) { const card = cards.find(c => c.id === cardId); handleCardUpdate(cardId, { listId: list.id }, card); } }}>
                  {listCards.length === 0 && <div className="border-2 border-dashed border-gray-200 rounded-xl p-4 text-center"><p className="text-xs text-gray-400">Vazio</p></div>}
                  {listCards.map(card => (
                    <div key={card.id} draggable onDragStart={e => e.dataTransfer.setData('cardId', card.id)} onClick={() => { setEditingCard(card); setIsModalOpen(true); }} className={`bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md cursor-pointer group relative transition-all`}>
                      <div className="flex items-center justify-between mb-2">
                        {card.type && <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${CONTENT_TYPES[card.type]?.color}`}>{CONTENT_TYPES[card.type]?.icon && React.createElement(CONTENT_TYPES[card.type].icon, { className: "w-3 h-3" })}{CONTENT_TYPES[card.type]?.label}</span>}
                        <Instagram className="w-3 h-3 text-gray-300"/>
                      </div>
                      <h4 className="font-bold text-slate-800 text-sm mb-2 leading-snug">{card.title}</h4>
                      <div className="flex items-center gap-3 text-xs text-gray-400 mb-1">{card.dueDate && <span className={`flex items-center gap-1 ${card.isLate ? 'text-red-500 font-bold' : ''}`}><Calendar className="w-3 h-3" /> {formatDateDisplay(card.dueDate)}</span>}</div>
                      {(card.timerStart) && <div className="mt-2"><ActiveTimerDisplay start={card.timerStart} accumulated={card.isAdjustmentSession ? card.adjustmentTime : card.productionTime} /></div>}
                      {(card.productionTime > 0 || card.adjustmentTime > 0) && !card.timerStart && (<div className="mt-1 flex gap-1 flex-wrap">{card.productionTime > 0 && <StaticTimerDisplay total={card.productionTime} label="Prod" />}{card.adjustmentTime > 0 && <StaticTimerDisplay total={card.adjustmentTime} label="Ajuste" />}</div>)}
                      <div className="flex gap-2 mt-3 pt-2 border-t border-gray-50">
                          {card.listId === 'ideas' && <button onClick={(e) => {e.stopPropagation(); handleCardUpdate(card.id, { listId: 'production' }, card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200">🚀 Iniciar</button>}
                          {card.listId === 'production' && <button onClick={(e) => {e.stopPropagation(); handleCardUpdate(card.id, { listId: 'review' }, card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-orange-100 text-orange-700 rounded hover:bg-orange-200">📤 Revisão</button>}
                          {card.listId === 'review' && <button onClick={(e) => {e.stopPropagation(); setEditingCard(card); setIsModalOpen(true);}} className="flex-1 py-1.5 text-[10px] font-bold bg-blue-100 text-blue-700 rounded hover:bg-blue-200">⚡ Avaliar</button>}
                          {card.listId === 'distribute' && <button onClick={(e) => {e.stopPropagation(); const date = prompt("Data (AAAA-MM-DDTHH:MM):", new Date().toISOString().slice(0,16)); if(date){ handleCardUpdate(card.id, { listId: 'schedule', dueDate: date }, card); }}} className="flex-1 py-1.5 text-[10px] font-bold bg-indigo-100 text-indigo-700 rounded hover:bg-indigo-200">📅 Agendar</button>}
                          {card.listId === 'delayed' && <button onClick={(e) => {e.stopPropagation(); handleCardUpdate(card.id, { listId: 'production' }, card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-red-100 text-red-700 rounded hover:bg-red-200">🔥 Destravar</button>}
                          {card.listId === 'approved' && <button onClick={(e) => {e.stopPropagation(); handleCardUpdate(card.id, { listId: 'distribute' }, card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-green-100 text-green-700 rounded hover:bg-green-200">📦 Distribuir</button>}
                          {card.listId === 'schedule' && <button onClick={(e) => {e.stopPropagation(); handleCardUpdate(card.id, { listId: 'published' }, card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-purple-100 text-purple-700 rounded hover:bg-purple-200">🚀 Publicar</button>}
                          {card.listId === 'published' && <button onClick={(e) => {e.stopPropagation(); handleArchive(card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-gray-100 text-gray-500 rounded hover:bg-gray-200">🗄️ Arquivar</button>}
                          {card.listId === 'adjusts' && <button onClick={(e) => {e.stopPropagation(); handleCardUpdate(card.id, { listId: 'production' }, card)}} className="flex-1 py-1.5 text-[10px] font-bold bg-blue-100 text-blue-700 rounded hover:bg-blue-200">🛠️ Corrigir</button>}
                      </div>
                    </div>
                  ))}
                  {currentUserProfile.permissions.create_content && <button onClick={() => { setEditingCard({ listId: list.id, environment: currentEnv }); setIsModalOpen(true); }} className="w-full py-2 text-sm text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg dashed border border-transparent hover:border-indigo-200 transition-all flex items-center justify-center gap-1"><Plus className="w-4 h-4" /> Criar</button>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  // --- LOGIN FLOW ---
  if (!currentUserProfile) {
    return <LoginScreen onLogin={handleLogin} error={loginError} />;
  }

  if (loading) return <div className="h-screen flex items-center justify-center text-indigo-600 bg-slate-50"><RefreshCw className="animate-spin w-8 h-8" /></div>;

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-800 overflow-hidden">
      {toast && <div className={`fixed bottom-6 right-6 px-6 py-3 rounded-xl shadow-xl text-white font-bold z-[100] animate-in slide-in-from-bottom-5 ${toast.type === 'error' ? 'bg-rose-500' : toast.type === 'info' ? 'bg-blue-600' : toast.type === 'warning' ? 'bg-orange-500' : 'bg-emerald-600'}`}>{toast.message}</div>}

      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-gray-100 flex flex-col transition-transform md:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
         <div className="p-6"><div className="flex items-center gap-2 font-bold text-xl text-indigo-900 tracking-tight"><div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-indigo-200 shadow-lg"><Flame className="w-5 h-5 fill-current" /></div>VeraCruz</div><div className="mt-6"><label className="text-[10px] font-bold uppercase text-gray-400 ml-1">Ambiente</label><div className="relative mt-1"><div className="flex items-center justify-between w-full appearance-none bg-gray-50 border border-gray-200 text-slate-700 text-sm font-bold rounded-xl py-2 pl-3 pr-2"><select value={currentEnv} onChange={(e) => setCurrentEnv(e.target.value)} className="bg-transparent border-none focus:ring-0 text-slate-700 text-sm font-bold w-full outline-none">{availableEnvs.map(env => <option key={env} value={env}>{env}</option>)}</select></div><div className="flex gap-1 mt-1 justify-end"><button onClick={handleRenameEnvironment} className="p-1 text-gray-400 hover:text-indigo-600" title="Renomear"><Pencil className="w-3 h-3"/></button><button onClick={handleAddEnvironment} className="p-1 text-gray-400 hover:text-green-600" title="Novo"><Plus className="w-3 h-3"/></button></div></div></div></div>
         <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
            {currentUserProfile.permissions.view_analytics && <NavItem icon={LayoutDashboard} label="Relatórios" active={view === 'dashboard'} onClick={() => setView('dashboard')} />}
            <NavItem icon={Kanban} label="Produção" active={view === 'kanban'} onClick={() => setView('kanban')} />
            {currentUserProfile.permissions.create_content && <NavItem icon={Sparkles} label="Criação (IA)" active={view === 'creation'} onClick={() => setView('creation')} />}
            <NavItem icon={Calendar} label="Calendário" active={view === 'calendar'} onClick={() => setView('calendar')} />
            <NavItem icon={Archive} label="Arquivo Morto" active={view === 'archive'} onClick={() => setView('archive')} />
            {currentUserProfile.permissions.access_settings && <NavItem icon={Settings} label="Configurações" active={view === 'settings'} onClick={() => setView('settings')} />}
         </nav>
         <div className="p-4 border-t border-gray-100 flex items-center justify-between">
            <button onClick={() => setIsProfileModalOpen(true)} className="flex items-center gap-2 hover:bg-gray-50 p-2 rounded-lg transition-colors">
              <div className="w-8 h-8 bg-indigo-100 text-indigo-700 rounded-full flex items-center justify-center font-bold text-xs overflow-hidden">
                 {currentUserProfile.photoURL ? <img src={currentUserProfile.photoURL} alt="User" className="w-full h-full object-cover" /> : (currentUserProfile.name || '').substr(0,2)}
              </div>
              <div className="text-left hidden md:block">
                 <p className="text-xs font-bold text-slate-800">{currentUserProfile.name}</p>
                 <p className="text-[10px] text-gray-400">Editar Perfil</p>
              </div>
            </button>
            <button onClick={handleLogout} className="text-red-400 hover:text-red-600 p-2"><LogOut className="w-4 h-4"/></button>
         </div>
      </aside>

      <main className="flex-1 flex flex-col md:ml-64 relative overflow-hidden">
        <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-6 shrink-0 z-30">
           <div className="flex items-center gap-4"><button className="md:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}><Menu /></button>
              {view === 'kanban' && (<div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl"><button onClick={() => setFilterFormat('all')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'all' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>Todos</button><button onClick={() => setFilterFormat('distribute')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'distribute' ? 'bg-indigo-600 shadow-sm text-white' : 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100'}`}>Distribuir</button><div className="w-px h-4 bg-gray-300 mx-1"></div><button onClick={() => setFilterFormat('reels')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'reels' ? 'bg-white shadow-sm text-pink-600' : 'text-gray-500 hover:text-gray-700'}`}>Reels</button><button onClick={() => setFilterFormat('carrossel')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'carrossel' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>Carrossel</button><button onClick={() => setFilterFormat('static')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'static' ? 'bg-white shadow-sm text-purple-600' : 'text-gray-500 hover:text-gray-700'}`}>Estáticos</button><button onClick={() => setFilterFormat('photo')} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterFormat === 'photo' ? 'bg-white shadow-sm text-emerald-600' : 'text-gray-500 hover:text-gray-700'}`}>Fotos</button></div>)}
           </div>
           <div className="flex items-center gap-4">{currentUserProfile.permissions.create_content && <button onClick={() => { setEditingCard({ environment: currentEnv }); setIsModalOpen(true); }} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-indigo-200 transition-transform active:scale-95"><Plus className="w-4 h-4" /> Novo</button>}</div>
        </header>

        <div className="flex-1 overflow-hidden relative flex flex-col w-full">
          {view === 'dashboard' && renderDashboard()}
          {view === 'kanban' && renderKanban()}
          {view === 'creation' && renderContentCreation()}
          {view === 'calendar' && renderCalendar()}
          {view === 'settings' && renderSettings()}
          {view === 'archive' && renderArchive()}
        </div>
      </main>

      {isModalOpen && <CardModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} editingCard={editingCard} currentEnv={currentEnv} user={currentUserProfile} userPermissions={currentUserProfile.permissions} handleCardUpdate={handleCardUpdate} showToast={showToast} />}
      {isProfileModalOpen && <UserProfileModal user={currentUserProfile} onClose={() => setIsProfileModalOpen(false)} onSave={handleSaveProfile} />}
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 20px; border: 2px solid transparent; background-clip: content-box; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background-color: #94a3b8; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}

const NavItem = ({ icon: Icon, label, active, onClick }) => (
  <button onClick={onClick} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${active ? 'bg-indigo-50 text-indigo-600' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}>
    <Icon className={`w-5 h-5 ${active ? 'fill-current opacity-20' : ''}`} /> {label}
  </button>
);