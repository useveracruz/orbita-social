// Shim mínimo para permitir preview sem Firebase real.
// Implementações são simuladas e não persistem dados.
export function initializeApp(config) {
  return { config };
}
export function getAuth() {
  return {};
}
export function signInAnonymously() {
  return Promise.resolve({ user: { uid: 'anon' } });
}
export function onAuthStateChanged(auth, cb) {
  // Simula um usuário anônimo conectado após breve atraso
  const t = setTimeout(() => cb({ uid: 'anon', isAnonymous: true }), 120);
  return () => clearTimeout(t);
}
export function signInWithCustomToken() {
  return Promise.resolve({ user: { uid: 'custom' } });
}

// Firestore shim (muito simples)
export function getFirestore() {
  return {};
}
export function collection() {
  return {};
}
export function doc() {
  return {};
}
export function addDoc() {
  return Promise.resolve({ id: Math.random().toString(36).slice(2) });
}
export function updateDoc() {
  return Promise.resolve();
}
export function deleteDoc() {
  return Promise.resolve();
}
export function onSnapshot(queryObj, cb) {
  // envia snapshot vazio inicialmente
  const snapshot = {
    docs: [],
    forEach: () => {}
  };
  const t = setTimeout(() => cb(snapshot), 50);
  return () => clearTimeout(t);
}
export function query() {
  return {};
}
export function serverTimestamp() {
  return new Date().toISOString();
}
export function where() {
  return {};
}
export function writeBatch() {
  return { commit: () => Promise.resolve() };
}
export async function getDocs() {
  return { docs: [], forEach: () => {} };
}
export async function getDoc() {
  return { exists: () => false, data: () => ({}) };
}
export async function setDoc() {
  return Promise.resolve();
}